import './App.css';
import About from './comp/About';
import Cards from './comp/Cards';
import Contact from './comp/Contact';
import Skills from './comp/Skills';
import Works from './comp/Works';


function App() {
  return (

    <div>
      <header>
        <img src="/imgs/star.svg"></img>
      </header>
      <div className='box'>
        <div className='boxTxt'>
          <div className='title'>
            <h2>PORT <br /> FOLIO</h2>
            {/* <p className="subtitle">FRONTEND DEVELOPER</p> */}
            <p className="subtitle"> “지속적인 개선을 통해 성장하는 개발자”</p> 
          </div>
          <div className='btn'>
            <button>GITHUB</button>
            <button>CONTACT</button>
          </div>
        </div>
        <Cards />
      </div>

      <div className='sticky_menu'>
        <div className='sticky_text'>
          <div>
            <span className="gradient">ABOUT</span>
          </div>
          <div>
            <span className="gradient">SKILLS</span>
          </div>
          <div>
            <span className="gradient">WORKS</span>
          </div>
          <div>
            <span className="gradient">CONTACT</span>
          </div>
        </div>

        <div className='section'>
          {/* About 부분 */}
          <About />

          {/* 스킬 부분 */}
          <Skills />

          {/* Works 부분 */}
          <Works />

          {/* contact 부분 */}
          <Contact />




        </div>




      </div>












    </div >









  );
}

export default App;
