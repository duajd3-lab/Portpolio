import React from 'react'
import '../about.scss'

function About() {
  return (
    <div className='aboutBox'>
      <div className='boxTitle'>
        <h3>ABOUT</h3>
      </div>
      <div className='static_box'>
        <div className='pro_box'>
          <div className='profile'>
            <img src='./imgs/pink.jpg' />
          </div>
          <span>Frontend Developer</span>
          <p>김나영입니다</p>
          <div>
            <p>
              사용자 중심의 인터페이스를 고민하고 <br />
              더 나은 경험을 제공하는 방향으로 <br />
              서비스를 개선해나가는 개발자가 되고 싶습니다.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default About