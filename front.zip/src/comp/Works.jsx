import React, { useState } from 'react'
import '../works.scss'
import Popup from './Popup';

function Works() {

  const [open, setOpen] = useState(false);

  return (
    <>
      <div className='worksBox'>
        <div className='boxTitle'>
          <h3>WORKS</h3>
        </div>
        <div className='project'>
          <div className="mockup">
            <img src='./imgs/ipad.png' className='ipad' />
            <img src='./imgs/weather.png' className='screen' />
          </div>
          <div className='project-box'>
            <div className='project-txt'>
              <span>날씨에 따라 코디와 음악 등을 추천받는 날씨 추천 앱(WEB)</span>
              <li>날씨 API 를 활용하여 실시간 으로 데이터를 받는 시스템</li>
              <li>LocalStorge를 활용하여 데이터 연동하여 개발</li>
              <span>SKILLS</span>
              <p>HTML5, JavaScript, CSS</p>
            </div>
            <div className='project-btn'>
              <button>
                <img src='./imgs/link.svg' className='linkSvg' /> GITHUB
              </button>
              <button onClick={() => setOpen(true)}>자세히 보기</button>
              {open && <Popup setOpen={setOpen} />}
            </div>
          </div>
        </div>

        <div className='project'>
          <div className="mockup" onClick={() => window.open("https://react-todolist-zw2e.vercel.app/")}>
            <img src='./imgs/ipad.png' className='ipad' />
            <img src='./imgs/todolist.png' className='screen' />
          </div>
          <div className='project-box'>
            <div className='project-txt'>
              <span>사용자의 일정 관리 효율을 높이기 위한 TODOLIST</span>
              <li>LocalStorge를 활용하여 데이터 연동하여 개발</li>
              <span>SKILLS</span>
              <p>REACT, SASS</p>
            </div>
            <div className='project-btn'>
              <button>
                <img src='./imgs/link.svg' /> GITHUB
              </button>
              <button onClick={() => setOpen(true)}>자세히 보기</button>
            </div>
          </div>
        </div>
      </div>
      {open && <Popup setOpen={setOpen} /> }
    </>
  )
}

export default Works