import React from 'react'
import '../popup.scss'

function Popup({setOpen}) {
  return (
    <div className='modal' onClick={()=> {setOpen(false)}}>
        <span>날씨에 따라 코디와 음악 등을 추천받는 날씨 추천 앱(WEB)</span>
        <img src='./imgs/weather.png' className='screen' />
        <div>
            <div>
                <span>SKILLS</span>
            </div>
            <div>
                <div>HTML5</div>
                <div>HTML5</div>
            </div>
            <div>
                <span>사이트</span>
            </div>
            <div>
                <span>개발인원</span>
                <p>개발자 1명</p>
            </div>
            <div>
                <span>상세 기능</span>
                <li>날씨 API 를 활용하여 실시간 으로 데이터를 받는 시스템</li>
                <li>LocalStorge를 활용하여 데이터 연동하여 개발</li>
            </div>
            <div>
                <span>트러블 슈팅</span>
                <li>[문제 상황]</li>
                <p>- 리스트가 많아질수록 렌더링 성능 저하 발생</p>
                <li>[해결 방법]</li>
                <p>- React.memo와 useCallback 적용</p>
                <p>- React.memo와 useCallback 적용</p>
                <li>[성과]</li>
            </div>

        </div>

    </div>
  )
}

export default Popup