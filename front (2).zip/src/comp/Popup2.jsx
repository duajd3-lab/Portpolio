import '../popup.scss'

import React, { useEffect, useRef, useState } from 'react';
// Import Swiper React components
import { Swiper, SwiperSlide } from 'swiper/react';

// Import Swiper styles
import 'swiper/css';
import 'swiper/css/pagination';
import 'swiper/css/navigation';


// import required modules
import { Autoplay, Pagination, Navigation } from 'swiper/modules';

function Popup2({ setOpen }) {
  const modal = useRef();
      const container = useRef();
  
      useEffect(() => {
          modal.current.addEventListener('wheel', function (e) {
              e.preventDefault();
          })
          container.current.addEventListener('wheel', function (e) {
              e.stopPropagation();
          })
      }, [])
      return (
          <div className='modal' ref={modal} onClick={() => { setOpen(false) }} >
  
              <div className='container' ref={container} onClick={(e) => e.stopPropagation()} >
                  <span>사용자의 일정 관리 효율을 높이기 위한 TODOLIST</span>
                 <span className="close-icon" onClick={() => setOpen(null)}>✖</span>
  
                  <>
                      <Swiper
                          spaceBetween={30}
                          centeredSlides={true}
                          autoplay={{
                              delay: 3500,
                              disableOnInteraction: false,
                          }}
                          pagination={{
                              clickable: true,
                          }}
                          navigation={true}
                          modules={[Autoplay, Pagination, Navigation]}
                          className="mySwiper"
                      >
                          <SwiperSlide><img src='/imgs/todolist.png' className='screen' /></SwiperSlide>
                          <SwiperSlide>Slide 2</SwiperSlide>
                          <SwiperSlide>Slide 3</SwiperSlide>
                          <SwiperSlide>Slide 4</SwiperSlide>
                          <SwiperSlide>Slide 5</SwiperSlide>
                          <SwiperSlide>Slide 6</SwiperSlide>
                      </Swiper>
                  </>
  
  
  
  
                  {/* <div className="image-container">
                      <img src='/imgs/weather.png' className='screen' />
                      </div> */}
  
                  <div className="details">
                      <section className='sec-1'>
                          <div className='tt'>
                              <span>SKILLS</span>
                          </div>
                          <div className="skills">
                              <div>REACT</div>
                              <div>SASS</div>
                          </div>
                      </section>
  
                      <section className='sec-1'>
                          <div className='tt'>
                              <span>사이트</span>
                          </div>
                      </section>
  
                      <section className='sec-2'>
                          <div className='tt2'>
                              <span>개발인원</span>
                          </div>
                          <div className='tt-text'>
                              <div>개발자 1명</div>
                          </div>
                      </section>
  
                      <section className='sec-1'>
                          <div className='tt2'>
                              <span>상세 기능</span>
                              <ul>
                                  <li>날씨 API 를 활용하여 실시간 으로 데이터를 받는 시스템</li>
                                  <li>LocalStorage를 활용하여 데이터 연동하여 개발</li>
                              </ul>
                          </div>
                      </section>
  
                      <section className='sec-1'>
                          <div className='tt'>
                              <span>트러블 슈팅</span>
                              <ul>
                                  <li>[문제 상황] - 리스트가 많아질수록 렌더링 성능 저하 발생</li>
                                  <li>[해결 방법] - React.memo와 useCallback 적용</li>
                                  <li>[성과] - 성능 개선</li>
                              </ul>
                          </div>
                      </section>
                  </div>
  
  
              </div>
          </div>
      )
}

export default Popup2