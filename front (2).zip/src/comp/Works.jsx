import React, { useState } from 'react'
import '../works.scss'
import Popup from './Popup';
import Popup2 from './Popup2';
import data from '../json/project.json'

function Works() {

  const [open1, setOpen1] = useState(false);
  const [open2, setOpen2] = useState(false);

  return (
    <>
      <div className='worksBox'>
        <div className='boxTitle'>
          <h3>WORKS</h3>
        </div>
        {
          data.map((item) => {
            return <div className='project' key={item}>
              <div className="mockup" onClick={() => window.open("https://duajd3-lab.github.io/Weather-Mood/index.html")}>
                <img src='./imgs/ipad.png' className='ipad' />
                <img src='./imgs/weather.png' className='screen' />
              </div>
              <div className='project-box'>
                <div className='project-txt'>
                  <h3>{item.title}</h3>
                  <div className='li-txt'>
                    <li>날씨 API 를 활용하여 실시간 으로 데이터를 받는 시스템</li>
                    <li>LocalStorge를 활용하여 데이터 연동하여 개발</li>
                  </div>
                  <span>SKILLS</span>
                  <p>HTML5, JavaScript, CSS</p>
                </div>
                <div className='project-btn'>
                  <button onClick={() => window.open("https://github.com/duajd3-lab/Weather-Mood")}>
                    <img src='./imgs/link.svg' className='linkSvg' /> GITHUB
                  </button>
                  <button onClick={() => setOpen1(true)}>자세히 보기</button>
                  {open1 && <Popup setOpen={setOpen1} item={item} />}
                </div>
              </div>
            </div>
          })
        }


      </div>
    </>
  )
}

export default Works