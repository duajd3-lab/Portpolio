import React from 'react'
import '../contact.scss'

function Contact() {
  return (

    <div className='contact'>
      <div className='boxTitle'>
        <h3>CONTACT</h3>
      </div>
      
      <CardItem />
    </div>

  )
}

export default Contact


function CardItem() {
    return (
        <div className='card-wrap'>
          <div className='card2 back'></div>

          <div className='card2 front'>
              <div className='cardText2'>
                  <p className="small">FRONTEND DEVELOPER</p>
                  <h3>김 나 영</h3>
                  <span className="email">example@gmail.com</span>
              </div>
          </div>
        </div>
    );
}