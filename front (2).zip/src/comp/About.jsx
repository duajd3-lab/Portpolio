import React from 'react'
import '../about.scss'

function About() {
  return (
    <div className='aboutBox'>
      <div className='boxTitle'>
        <h3>ABOUT</h3>
      </div>
      <div className='static_box'>
        <div className='pro_box'>
          <div className='profile'>
            <img src='./imgs/pink.jpg' />
          </div>
          <span>Frontend Developer</span>
          <div className='profile-txt'>
            <p>안녕하세요.  <br />
              사용자 중심의 인터페이스를 고민하고 <br />
              더 나은 경험을 제공하는 방향으로 <br />
              서비스를 개선해나가는 개발자
            </p>
            <p><span>김나영</span> 입니다.</p>
          </div>
        </div>
        <div className="value-simple">
          <div className="value-item">💡 사용자 경험을 중요하게 생각합니다</div>
          <div className="value-item">🧹 가독성 높은 코드를 작성합니다</div>
          <div className="value-item">📈 꾸준히 성장합니다</div>
        </div>
      </div>
    </div>
  )
}

export default About